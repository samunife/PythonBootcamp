$(document).ready(function() {
  // Manejar el clic en "Ver más"
  $(".text-body-secondary").click(function() {
      var idBoton = $(this).attr("id"); // Obtiene el ID del botón clicado
      $("#detalles" + idBoton).toggle(); // Muestra/Oculta el div correspondiente
  });

  // Manejar el clic en el botón de cierre (X)
  $(".btn-close").click(function() {
      $(this).closest(".detalles").hide(); // Oculta solo el contenedor de detalles asociado
  });
});
